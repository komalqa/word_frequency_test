class CountWordsSpec {

    public static void main(String args[]) {
		CountWords cw = new CountWords("input.txt");
		
        if (cw.run().size() == 197) {
            System.out.println("Assertion passed for given input");
        } else {
            System.out.println("Failed");
        }
    }
}