import java.io.*;
import java.util.*;

public class CountWords {
   String filePath; 

   CountWords(String filePath){
      this.filePath = filePath;
   }

    public List run(){
        String input;
        String[] words = new String[1000];
        ArrayList output = new ArrayList<>();
        int line = 0;
        File file;

        try{
         file = new File("input.txt");
         BufferedReader br = new BufferedReader(new FileReader(file));
 
         while ((input = br.readLine()) != null) {
             words[line] = input;
             line++;
         } 
        }catch(Exception e){
          System.out.println("Unable to find the file");
        }

        int wrc = 1; //Variable for getting Repeated word count

        for (int i = 0; i < words.length; i++) //Outer loop for Comparison       
        {
            for (int j = i + 1; j < words.length; j++) //Inner loop for Comparison
            {

                if (words[i].equals(words[j])) //Checking for both strings are equal
                {
                    wrc = wrc + 1; //if equal increment the count
                    words[j] = "0"; //Replace repeated words by zero
                }
            }
            if (words[i] != "0") {
               if(wrc > 1){
                  output.add(words[i]);
                  System.out.println(words[i] + " " + wrc); //Printing the word along with count
               }                
            }
            wrc = 1;
        }

        return output;
    }
}