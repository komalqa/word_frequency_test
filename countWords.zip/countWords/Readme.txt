Steps to run the application
----------------------------
1. Compile the source files
	ex: 
		javac CountWords.java 
		javac CountWordsSpec.java 

2. Run the Spec file
	ex: 
		java CountWordsSpec


About
----
CountWordsSpec.java file is to assert the results from the given input text file and run the logic and finally assert the result.

	
